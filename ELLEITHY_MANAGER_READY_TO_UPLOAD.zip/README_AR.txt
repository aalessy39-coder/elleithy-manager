ELLEITHY MANAGER — prepared files

Contains:
- Web/PWA files at root: index.html, manifest.webmanifest, sw.js, icons/
- Android project archive: FleetManagerPro_Android.zip
- GitHub Actions workflow: .github/workflows/build-android.yml

The workflow builds an Android debug APK on GitHub Actions and makes it downloadable as an artifact. This bundle does not itself contain a prebuilt APK.
