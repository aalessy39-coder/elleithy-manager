اسم التطبيق: ELLEITHY MANAGER
واجهة التطبيق الداخلية باللغة العربية.

Fleet Manager Pro — مشروع أندرويد (ليس APK جاهزًا)

افتح المجلد في Android Studio ثم Build > Build APK(s).
ملف APK الناتج سيكون داخل app/build/outputs/apk/debug/.
التطبيق يفتح واجهة عربية محليًا ويحتاج إنترنت لتسجيل الدخول وتحميل وحفظ بيانات Supabase.
لا توجد مزامنة دون إنترنت ولا GPS تلقائي حتى الآن.
تحذير: تطبيق WebView المحلي قد يحتاج ضبط سياسة الوصول أو الانتقال إلى رابط HTTPS منشور إذا منع Android WebView طلبات Supabase من file://.
