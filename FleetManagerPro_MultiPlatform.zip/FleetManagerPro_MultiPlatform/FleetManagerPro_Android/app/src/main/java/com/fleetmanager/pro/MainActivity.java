package com.fleetmanager.pro;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebResourceRequest;
import android.content.Intent;
import android.net.Uri;
public class MainActivity extends Activity {
  private WebView web;
  @Override public void onCreate(Bundle state) { super.onCreate(state);
    web = new WebView(this); setContentView(web);
    WebSettings settings = web.getSettings();
    settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true);
    settings.setAllowFileAccess(true); settings.setAllowContentAccess(false);
    settings.setAllowFileAccessFromFileURLs(false); settings.setAllowUniversalAccessFromFileURLs(false);
    web.setWebChromeClient(new WebChromeClient());
    web.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
        Uri uri=request.getUrl();
        if ("http".equals(uri.getScheme()) || "https".equals(uri.getScheme())) {
          startActivity(new Intent(Intent.ACTION_VIEW, uri)); return true;
        } return false;
      }
    });
    web.loadUrl("file:///android_asset/index.html");
  }
  @Override public void onBackPressed() { if(web.canGoBack())web.goBack(); else super.onBackPressed(); }
}
